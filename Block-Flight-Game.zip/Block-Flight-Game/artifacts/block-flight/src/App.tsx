import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  createGameEngine,
  type BlockId,
  type GameEngine,
  type GameSnapshot,
  type GraphicsMode,
} from '@/game/engine';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

const graphicsModes: {
  id: GraphicsMode;
  label: string;
  subtitle: string;
  detail: string;
}[] = [
  {
    id: 'low',
    label: 'Low',
    subtitle: 'First-version inspired',
    detail: 'Simpler, chunkier pixels',
  },
  {
    id: 'normal',
    label: 'Normal',
    subtitle: 'Current graphics',
    detail: 'The look you have now',
  },
  {
    id: 'ultra',
    label: 'Ultra',
    subtitle: '32-bit style',
    detail: 'Sharper, denser textures',
  },
  {
    id: 'ultimate',
    label: 'Ultimate',
    subtitle: '128-bit style',
    detail: 'Dynamic light, larger world, roaming mobs',
  },
  {
    id: 'crysis',
    label: 'Can it run Crysis',
    subtitle: '2K textures · WebGL2',
    detail: 'True 3D, 8 streamed chunks (8×8 blocks each), dynamic shadows, near-limitless building',
  },
];

function Home() {
  const [playing, setPlaying] = useState(false);
  const [paused, setPaused] = useState(false);
  const [graphicsMode, setGraphicsMode] = useState<GraphicsMode>('normal');
  const [graphicsError, setGraphicsError] = useState<string | null>(null);
  const [loadingGraphics, setLoadingGraphics] = useState(false);
  const [graphicsFallback, setGraphicsFallback] = useState(false);
  const [snapshot, setSnapshot] = useState<GameSnapshot>({
    altitude: 0,
    verticalSpeed: 0,
    grounded: true,
    selectedBlock: 1,
  });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!playing || !canvas) return;
    let cancelled = false;
    let engine: GameEngine | null = null;
    const startEngine = async () => {
      setLoadingGraphics(true);
      setGraphicsFallback(false);
      try {
        const createdEngine = await createGameEngine(canvas, setSnapshot, graphicsMode);
        if (cancelled) {
          createdEngine.stop();
          return;
        }
        engine = createdEngine;
        engineRef.current = createdEngine;
        setGraphicsFallback(Boolean(createdEngine.graphicsFallback));
        createdEngine.start();
        setGraphicsError(null);
      } catch (error) {
        if (cancelled) return;
        const message = error instanceof Error ? error.message : '';
        setGraphicsError(
          message.toLowerCase().includes('webgl')
            ? 'Crysis could not start its WebGL 2 renderer. Enable WebGL 2 or choose another graphics mode.'
            : `Could not start this graphics mode${message ? `: ${message}` : '.'}`,
        );
        setGraphicsFallback(false);
        setPlaying(false);
      } finally {
        if (!cancelled) setLoadingGraphics(false);
      }
    };
    void startEngine();
    return () => {
      cancelled = true;
      setLoadingGraphics(false);
      engine?.stop();
      if (engineRef.current === engine) engineRef.current = null;
    };
  }, [playing, graphicsMode]);

  const togglePause = useCallback(() => {
    const engine = engineRef.current;
    if (!engine) return;
    if (paused) {
      engine.resume();
      setPaused(false);
    } else {
      engine.pause();
      setPaused(true);
    }
  }, [paused]);

  const restart = useCallback(() => {
    const engine = engineRef.current;
    if (!engine) return;
    engine.restart();
    setPaused(false);
  }, []);

  const selectSlot = useCallback((block: BlockId) => {
    engineRef.current?.selectBlock(block);
    setSnapshot((current) => ({ ...current, selectedBlock: block }));
  }, []);

  useEffect(() => {
    if (!playing) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.repeat) return;
      if (event.key === 'Escape' || event.key.toLowerCase() === 'p') {
        event.preventDefault();
        togglePause();
        return;
      }
      const slot = Number(event.key);
      if (slot >= 1 && slot <= 4) selectSlot(slot as BlockId);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [playing, selectSlot, togglePause]);

  const blocks: { id: BlockId; name: string; swatch: string }[] = [
    { id: 1, name: 'Grass', swatch: 'swatch-grass' },
    { id: 2, name: 'Stone', swatch: 'swatch-stone' },
    { id: 3, name: 'Dirt', swatch: 'swatch-earth' },
    { id: 4, name: 'Wood', swatch: 'swatch-wood' },
  ];

  if (!playing) {
    return (
      <main className="flight-app title-screen">
        <section className="title-copy" aria-labelledby="game-title">
          <div className="title-mark" aria-hidden="true" />
          <div className="eyebrow">A little world above the clouds</div>
          <h1 id="game-title">BLOCK <span>FLIGHT</span></h1>
          <p className="title-subtitle">
            Build a place in the sky. Step off the edge, catch the air, and see how far your own little world can reach.
          </p>
          <button className="primary-action" type="button" data-testid="button-play" onClick={() => { setGraphicsError(null); setPaused(false); setPlaying(true); }}>
            Play game
          </button>
          {graphicsError && <p className="graphics-error" role="alert">{graphicsError}</p>}
          <p className="credit">Created by Aditya Dhasmana</p>
        </section>
        <div className="title-art">
          <div className="pixel-sun" />
          <div className="cloud cloud-one" />
          <div className="cloud cloud-two" />
          <div className="island-scene">
            <div className="island-shadow" />
            <div className="island-top" />
            <div className="island-side" />
            <div className="tiny-tree tree-a" />
            <div className="tiny-tree tree-b" />
            <div className="floating-cube" />
          </div>
          <div className="scene-caption">01 / THE FLOATING MEADOW</div>
          <section className="graphics-settings" aria-labelledby="graphics-title">
            <div className="graphics-heading">
              <span className="mono-label">WORLD DETAIL</span>
              <h2 id="graphics-title">Choose graphics</h2>
            </div>
            <div className="graphics-options" role="group" aria-label="Graphics mode">
              {graphicsModes.map((mode) => (
                <button
                  className={`graphics-option ${graphicsMode === mode.id ? 'is-selected' : ''}`}
                  key={mode.id}
                  type="button"
                  aria-pressed={graphicsMode === mode.id}
                  data-testid={`graphics-mode-${mode.id}`}
                  onClick={() => { setGraphicsMode(mode.id); setGraphicsError(null); setGraphicsFallback(false); }}
                >
                  <span className="graphics-option-top">
                    <span className="graphics-option-name">{mode.label}</span>
                    <span className="graphics-option-subtitle">{mode.subtitle}</span>
                  </span>
                  <span className="graphics-option-detail">{mode.detail}</span>
                </button>
              ))}
            </div>
            <p className="graphics-note">
              Crysis uses WebGL2, 32-bit RGBA, and 2048×2048 textures. Without WebGL2 it switches to Canvas 2D; 2048-bit color depth is not a browser format.
            </p>
          </section>
        </div>
      </main>
    );
  }

  return (
    <main className={`flight-app game-screen ${graphicsMode === 'crysis' ? 'crysis-screen' : ''}`}>
      <canvas ref={canvasRef} className="game-canvas" aria-label="Block Flight game world" data-testid="game-canvas" />
      {loadingGraphics && (
        <div className="graphics-loading" role="status">
          Loading {graphicsModes.find((mode) => mode.id === graphicsMode)?.label} graphics…
        </div>
      )}
      <div className="world-floor" aria-hidden="true" />
      <div className="game-vignette" aria-hidden="true" />
      <header className="game-topbar">
         <div className="brand-mini">
          BLOCK FLIGHT
          <small>WORLD // {graphicsMode.toUpperCase()}</small>
          {graphicsFallback && <small className="graphics-fallback-status">CANVAS 2D FALLBACK</small>}
        </div>
        <div className="top-controls">
          <button className="pixel-button" type="button" data-testid="button-pause" onClick={togglePause}>
            {paused ? 'Resume' : 'Pause'} <span aria-hidden="true">[P]</span>
          </button>
          <button className="pixel-button" type="button" data-testid="button-restart" onClick={restart}>
            Restart
          </button>
          <button className="pixel-button" type="button" data-testid="button-title" onClick={() => { setPaused(false); setPlaying(false); }}>
            Exit
          </button>
        </div>
      </header>
      <section className="status-panel" aria-label="Flight status" aria-live="polite" data-testid="status-flight">
        <span className="mono-label">Altitude</span>
        <div className="altitude-value" data-testid="status-altitude">{Math.max(0, Math.round(snapshot.altitude))}<small>BLOCKS</small></div>
        <div className="flight-state" data-testid="status-grounded">
          {snapshot.grounded ? 'ON THE MEADOW' : snapshot.verticalSpeed > 0 ? 'RISING ON THE AIR' : 'FREE FLIGHT'}
        </div>
      </section>
      <div className="crosshair" aria-hidden="true" />
      <footer className="game-bottom">
        <div className="inventory-wrap">
          <div className="inventory-label">BUILD MATERIALS</div>
          <div className="inventory" role="group" aria-label="Select building block">
            {blocks.map((block) => (
              <button
                className="inventory-slot"
                key={block.id}
                type="button"
                aria-label={`Select ${block.name} block`}
                aria-pressed={snapshot.selectedBlock === block.id}
                data-testid={`button-block-${block.id}`}
                onClick={() => selectSlot(block.id)}
              >
                <span className="slot-key">{block.id}</span>
                <span className={`block-swatch ${block.swatch}`} aria-hidden="true" />
                <span className="slot-name">{block.name}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="controls-hint" data-testid="text-controls">
          <strong>W / S</strong> move &nbsp;·&nbsp; <strong>A / D</strong> turn &nbsp;·&nbsp; <strong>R</strong> rise &nbsp;·&nbsp; <strong>F</strong> descend<br />
          <strong>LEFT CLICK</strong> break &nbsp;·&nbsp; <strong>RIGHT CLICK</strong> place &nbsp;·&nbsp; <strong>1—4</strong> select &nbsp;·&nbsp; <strong>P</strong> pause
        </div>
      </footer>
      {paused && (
        <div className="pause-overlay" role="dialog" aria-modal="true" aria-labelledby="pause-title" data-testid="status-paused">
          <div className="pause-card">
            <div className="mono-label">WORLD SAVED IN PLACE</div>
            <h2 id="pause-title">PAUSED</h2>
            <p>Your meadow is waiting. Pick up where the breeze left you.</p>
            <div className="pause-actions">
              <button className="primary-action" type="button" data-testid="button-resume" onClick={togglePause}>Resume flight</button>
              <button className="pixel-button" type="button" data-testid="button-restart-paused" onClick={restart}>Restart</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
