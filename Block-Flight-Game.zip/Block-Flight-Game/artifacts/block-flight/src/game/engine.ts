export type BlockId = 1 | 2 | 3 | 4;
export type GraphicsMode = "low" | "normal" | "ultra" | "ultimate" | "crysis";
type PresetGraphicsMode = Exclude<GraphicsMode, "crysis">;

export interface GameSnapshot {
  altitude: number;
  verticalSpeed: number;
  grounded: boolean;
  selectedBlock: BlockId;
}

export interface GameEngine {
  start(): void;
  restart(): void;
  pause(): void;
  resume(): void;
  stop(): void;
  selectBlock(block: BlockId): void;
  graphicsFallback?: boolean;
}

const FIELD_OF_VIEW = Math.PI / 3;
const WALL_HEIGHT = 1;
const EYE_HEIGHT = 0.5;
const GRAVITY = 4;
const FLIGHT_THRUST = 8;
const MAX_FLIGHT_HEIGHT = 2;
const MAX_VERTICAL_SPEED = 3;
const BASE_TEXTURE_SIZE = 64;

const GRAPHICS_CONFIG: Record<
  PresetGraphicsMode,
  {
    width: number;
    height: number;
    textureSize: number;
    clusterSize: number;
    worldSize: number;
    interactionDistance: number;
    dynamicLighting: boolean;
    mobCount: number;
  }
> = {
  low: {
    width: 216,
    height: 120,
    textureSize: 32,
    clusterSize: 8,
    worldSize: 16,
    interactionDistance: 8,
    dynamicLighting: false,
    mobCount: 0,
  },
  normal: {
    width: 360,
    height: 200,
    textureSize: 64,
    clusterSize: 4,
    worldSize: 16,
    interactionDistance: 8,
    dynamicLighting: false,
    mobCount: 0,
  },
  ultra: {
    width: 540,
    height: 300,
    textureSize: 128,
    clusterSize: 2,
    worldSize: 16,
    interactionDistance: 8,
    dynamicLighting: false,
    mobCount: 0,
  },
  ultimate: {
    width: 720,
    height: 400,
    textureSize: 256,
    clusterSize: 1,
    worldSize: 32,
    interactionDistance: 18,
    dynamicLighting: true,
    mobCount: 6,
  },
};

type Texture = {
  canvas: HTMLCanvasElement;
  pixels: ImageData;
};

type Cell = {
  x: number;
  y: number;
};

type RayHit = {
  cell: Cell;
  previous: Cell;
  distance: number;
};

type Mob = {
  x: number;
  y: number;
  direction: number;
  turnIn: number;
  color: string;
};

const PALETTES: Record<BlockId, string[]> = {
  1: ["#207e2a", "#2a9730", "#39ab3a", "#53bb45"],
  2: ["#5b6065", "#6e7479", "#82888c", "#979c9f", "#a9adaf"],
  3: ["#693e1f", "#7e4b24", "#91582b", "#a06533", "#b1753d"],
  4: ["#6c3f1f", "#844e25", "#995e2d", "#ae6f36"],
};

function makeRandom(seed: number) {
  let value = seed >>> 0;
  return () => {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 0x100000000;
  };
}

function makeTextureCanvas(size: number) {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d", { willReadFrequently: true })!;
  context.setTransform(size / BASE_TEXTURE_SIZE, 0, 0, size / BASE_TEXTURE_SIZE, 0, 0);
  return {
    canvas,
    context,
  };
}

function fillClusters(
  context: CanvasRenderingContext2D,
  palette: string[],
  random: () => number,
  clusterSize: number,
) {
  for (let y = 0; y < BASE_TEXTURE_SIZE; y += clusterSize) {
    for (let x = 0; x < BASE_TEXTURE_SIZE; x += clusterSize) {
      context.fillStyle = palette[Math.floor(random() * palette.length)];
      context.fillRect(x, y, clusterSize, clusterSize);
    }
  }
}

function createTexture(
  type: BlockId,
  textureSize: number,
  clusterSize: number,
): Texture {
  const { canvas, context } = makeTextureCanvas(textureSize);
  const random = makeRandom(903 + type * 211);

  if (type === 1) {
    const dirtPalette = ["#693e1f", "#7e4e28", "#915b2f", "#a46a39"];
    for (let y = 0; y < BASE_TEXTURE_SIZE; y += clusterSize) {
      const palette = y < 16 ? PALETTES[1] : dirtPalette;
      for (let x = 0; x < BASE_TEXTURE_SIZE; x += clusterSize) {
        context.fillStyle = palette[Math.floor(random() * palette.length)];
        context.fillRect(x, y, clusterSize, clusterSize);
      }
    }
    context.fillStyle = "#256f26";
    context.fillRect(0, 14, BASE_TEXTURE_SIZE, 4);
    for (let x = 5; x < BASE_TEXTURE_SIZE; x += 11) {
      context.fillStyle = PALETTES[1][Math.floor(random() * PALETTES[1].length)];
      context.fillRect(x, 10, 2, 5);
    }
  } else {
    fillClusters(context, PALETTES[type], random, clusterSize);
    if (type === 2) {
      context.strokeStyle = "#484d52";
      context.lineWidth = 2;
      context.beginPath();
      context.moveTo(0, 21);
      context.lineTo(BASE_TEXTURE_SIZE, 21);
      context.moveTo(0, 43);
      context.lineTo(BASE_TEXTURE_SIZE, 43);
      context.moveTo(21, 0);
      context.lineTo(21, 21);
      context.moveTo(43, 22);
      context.lineTo(43, 43);
      context.moveTo(16, 44);
      context.lineTo(16, 64);
      context.stroke();
      context.fillStyle = "#bec1c2";
      context.fillRect(3, 6, 12, 2);
      context.fillRect(28, 31, 10, 2);
    } else if (type === 3) {
      for (const [x, y] of [[9, 13], [38, 29], [21, 51], [53, 45]]) {
        context.fillStyle = "#59351d";
        context.fillRect(x, y, 5, 4);
        context.fillStyle = "#be8045";
        context.fillRect(x + 2, y - 2, 4, 3);
      }
    } else {
      for (const y of [0, 16, 32, 48, 63]) {
        context.fillStyle = "#4d2d19";
        context.fillRect(0, y, BASE_TEXTURE_SIZE, 2);
      }
      context.fillStyle = "#dda052";
      for (const y of [8, 25, 41, 56]) {
        context.fillRect(6, y, 21, 2);
        context.fillRect(35, y + 2, 22, 2);
      }
    }
  }

  return {
    canvas,
    pixels: context.getImageData(0, 0, textureSize, textureSize),
  };
}

function createFloorTexture(textureSize: number, clusterSize: number): Texture {
  const { canvas, context } = makeTextureCanvas(textureSize);
  const palette = ["#1e7425", "#268b2b", "#319e30", "#41ae38", "#53b941"];
  const random = makeRandom(5142);
  fillClusters(context, palette, random, clusterSize);
  context.fillStyle = "#236325";
  context.fillRect(0, 0, BASE_TEXTURE_SIZE, 2);
  context.fillRect(0, 0, 2, BASE_TEXTURE_SIZE);
  context.fillStyle = "#64c048";
  for (const [x, y] of [[12, 18], [37, 9], [47, 42], [22, 53]]) {
    context.fillRect(x, y, 4, 4);
  }
  return {
    canvas,
    pixels: context.getImageData(0, 0, textureSize, textureSize),
  };
}

function makeMap(size: number) {
  const map = Array.from({ length: size }, () =>
    Array<number>(size).fill(0),
  );
  for (let i = 0; i < size; i += 1) {
    map[0][i] = 2;
    map[size - 1][i] = 2;
    map[i][0] = 2;
    map[i][size - 1] = 2;
  }
  return map;
}

function supportsCrysisWebGL2() {
  let context: WebGL2RenderingContext | null = null;
  try {
    const probeCanvas = document.createElement("canvas");
    context = probeCanvas.getContext("webgl2", {
      alpha: false,
      antialias: true,
      depth: true,
      powerPreference: "high-performance",
    });
    if (!context) return false;

    return (
      context.getParameter(context.MAX_TEXTURE_SIZE) >= 2048 &&
      context.getParameter(context.MAX_RENDERBUFFER_SIZE) >= 2048
    );
  } catch {
    return false;
  } finally {
    context?.getExtension("WEBGL_lose_context")?.loseContext();
  }
}

function createCrysisCanvasFallback(
  canvas: HTMLCanvasElement,
  onStateChange: (snapshot: GameSnapshot) => void,
): Promise<GameEngine> {
  return Promise.resolve(createGameEngine(canvas, onStateChange, "ultimate")).then(
    (engine) => {
      engine.graphicsFallback = true;
      return engine;
    },
  );
}

export function createGameEngine(
  canvas: HTMLCanvasElement,
  onStateChange: (snapshot: GameSnapshot) => void,
  graphicsMode: GraphicsMode,
): GameEngine | Promise<GameEngine> {
  if (graphicsMode === "crysis") {
    if (!supportsCrysisWebGL2()) {
      return createCrysisCanvasFallback(canvas, onStateChange);
    }
    return import("./crysisEngine").then(
      ({ createCrysisEngine }) => createCrysisEngine(canvas, onStateChange),
      () => createCrysisCanvasFallback(canvas, onStateChange),
    );
  }

  const graphics = GRAPHICS_CONFIG[graphicsMode];
  const viewWidth = graphics.width;
  const viewHeight = graphics.height;
  const textureSize = graphics.textureSize;
  const mapSize = graphics.worldSize;
  const interactionDistance = graphics.interactionDistance;
  const context = canvas.getContext("2d", { alpha: false })!;
  canvas.width = viewWidth;
  canvas.height = viewHeight;
  context.imageSmoothingEnabled = false;

  const textures: Record<BlockId, Texture> = {
    1: createTexture(1, textureSize, graphics.clusterSize),
    2: createTexture(2, textureSize, graphics.clusterSize),
    3: createTexture(3, textureSize, graphics.clusterSize),
    4: createTexture(4, textureSize, graphics.clusterSize),
  };
  const floor = createFloorTexture(textureSize, graphics.clusterSize);
  const keys = new Set<string>();

  let map = makeMap(mapSize);
  let playerX = mapSize / 2 - 0.5;
  let playerY = mapSize / 2 - 0.5;
  let playerZ = 0;
  let verticalSpeed = 0;
  let angle = 0;
  let selectedBlock: BlockId = 1;
  let active = false;
  let frameId = 0;
  let lastFrame = 0;
  let lastReport = 0;
  let listenersAttached = false;
  let worldTime = 0;
  const mobColors = ["#7cdf85", "#f0ca67", "#e98e83", "#94bce8", "#c29de4", "#f0a66b"];
  const createMobs = (): Mob[] => {
    const spawnPoints = [
      [playerX + 5, playerY - 1],
      [playerX + 7, playerY + 2],
      [playerX + 4, playerY + 5],
      [playerX - 3, playerY - 3],
      [playerX - 6, playerY + 2],
      [playerX + 1, playerY - 7],
    ];
    return spawnPoints.slice(0, graphics.mobCount).map(([x, y], index) => ({
      x: Math.max(1.5, Math.min(mapSize - 1.5, x)),
      y: Math.max(1.5, Math.min(mapSize - 1.5, y)),
      direction: Math.random() * Math.PI * 2,
      turnIn: 0.5 + Math.random() * 2,
      color: mobColors[index % mobColors.length],
    }));
  };
  let mobs = createMobs();

  const publishState = () => {
    const x = Math.floor(playerX);
    const y = Math.floor(playerY);
    const floorHeight = map[y]?.[x] ? WALL_HEIGHT : 0;
    onStateChange({
      altitude: Number(playerZ.toFixed(1)),
      verticalSpeed: Number(verticalSpeed.toFixed(1)),
      grounded: playerZ <= floorHeight + 0.001 && Math.abs(verticalSpeed) < 0.05,
      selectedBlock,
    });
  };

  const hitTest = (maxDistance = interactionDistance): RayHit | null => {
    const rayX = Math.cos(angle);
    const rayY = Math.sin(angle);
    let previousX = Math.floor(playerX);
    let previousY = Math.floor(playerY);
    const step = 0.025;

    for (let distance = step; distance <= maxDistance; distance += step) {
      const x = playerX + rayX * distance;
      const y = playerY + rayY * distance;
      if (x < 0 || x >= mapSize || y < 0 || y >= mapSize) return null;

      const cellX = Math.floor(x);
      const cellY = Math.floor(y);
      if (cellX === previousX && cellY === previousY) continue;
      if (map[cellY][cellX] > 0) {
        return {
          cell: { x: cellX, y: cellY },
          previous: { x: previousX, y: previousY },
          distance,
        };
      }
      previousX = cellX;
      previousY = cellY;
    }
    return null;
  };

  const breakBlock = () => {
    const hit = hitTest();
    if (!hit) return;
    const { x, y } = hit.cell;
    if (x === 0 || y === 0 || x === mapSize - 1 || y === mapSize - 1) return;
    map[y][x] = 0;
  };

  const placeBlock = () => {
    const hit = hitTest();
    if (!hit) return;
    const { x, y } = hit.cell;
    const { x: placeX, y: placeY } = hit.previous;
    const isAdjacent = Math.abs(placeX - x) + Math.abs(placeY - y) === 1;
    const isInterior =
      placeX > 0 &&
      placeX < mapSize - 1 &&
      placeY > 0 &&
      placeY < mapSize - 1;
    const isPlayerCell =
      placeX === Math.floor(playerX) && placeY === Math.floor(playerY);

    if (isAdjacent && isInterior && !isPlayerCell && map[placeY][placeX] === 0) {
      map[placeY][placeX] = selectedBlock;
    }
  };

  const onKeyDown = (event: KeyboardEvent) => {
    const movementKeys = [
      "KeyW",
      "KeyA",
      "KeyS",
      "KeyD",
      "ArrowUp",
      "ArrowDown",
      "ArrowLeft",
      "ArrowRight",
      "KeyR",
      "KeyF",
    ];
    if (!active) return;

    if (movementKeys.includes(event.code)) event.preventDefault();
    keys.add(event.code);

    const slot: Record<string, BlockId> = {
      Digit1: 1,
      Digit2: 2,
      Digit3: 3,
      Digit4: 4,
    };
    const block = slot[event.code];
    if (block) {
      selectedBlock = block;
      publishState();
    }
  };

  const onKeyUp = (event: KeyboardEvent) => {
    keys.delete(event.code);
  };

  const onMouseDown = (event: MouseEvent) => {
    if (!active) return;
    event.preventDefault();
    if (event.button === 0) breakBlock();
    if (event.button === 2) placeBlock();
  };

  const onContextMenu = (event: MouseEvent) => event.preventDefault();

  const attachListeners = () => {
    if (listenersAttached) return;
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    canvas.addEventListener("mousedown", onMouseDown);
    canvas.addEventListener("contextmenu", onContextMenu);
    listenersAttached = true;
  };

  const removeListeners = () => {
    if (!listenersAttached) return;
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    canvas.removeEventListener("mousedown", onMouseDown);
    canvas.removeEventListener("contextmenu", onContextMenu);
    listenersAttached = false;
    keys.clear();
  };

  const castWall = (rayAngle: number) => {
    const rayX = Math.cos(rayAngle);
    const rayY = Math.sin(rayAngle);
    let cellX = Math.floor(playerX);
    let cellY = Math.floor(playerY);
    const deltaX = rayX === 0 ? 1e30 : Math.abs(1 / rayX);
    const deltaY = rayY === 0 ? 1e30 : Math.abs(1 / rayY);
    const stepX = rayX < 0 ? -1 : 1;
    const stepY = rayY < 0 ? -1 : 1;
    let sideX =
      rayX < 0
        ? (playerX - cellX) * deltaX
        : (cellX + 1 - playerX) * deltaX;
    let sideY =
      rayY < 0
        ? (playerY - cellY) * deltaY
        : (cellY + 1 - playerY) * deltaY;
    let side = 0;

    for (let step = 0; step < mapSize * 4; step += 1) {
      if (sideX < sideY) {
        sideX += deltaX;
        cellX += stepX;
        side = 0;
      } else {
        sideY += deltaY;
        cellY += stepY;
        side = 1;
      }
      if (cellX < 0 || cellX >= mapSize || cellY < 0 || cellY >= mapSize) {
        return null;
      }
      const block = map[cellY][cellX];
      if (block > 0) {
        const distance =
          side === 0
            ? sideX - deltaX
            : sideY - deltaY;
        const wallPosition =
          side === 0 ? playerY + distance * rayY : playerX + distance * rayX;
        let textureX = Math.floor((wallPosition - Math.floor(wallPosition)) * textureSize);
        if ((side === 0 && rayX > 0) || (side === 1 && rayY < 0)) {
          textureX = textureSize - textureX - 1;
        }
        return { block: block as BlockId, distance, textureX };
      }
    }
    return null;
  };

  const renderMobs = (depthBuffer: Float32Array) => {
    for (const mob of mobs) {
      const dx = mob.x - playerX;
      const dy = mob.y - playerY;
      const distance = Math.hypot(dx, dy);
      const relativeAngle = Math.atan2(
        Math.sin(Math.atan2(dy, dx) - angle),
        Math.cos(Math.atan2(dy, dx) - angle),
      );
      if (Math.abs(relativeAngle) > FIELD_OF_VIEW / 2 + 0.15) continue;

      const screenX = Math.round(
        (0.5 + relativeAngle / FIELD_OF_VIEW) * viewWidth,
      );
      const spriteHeight = Math.max(3, (0.68 * viewHeight) / distance);
      const spriteWidth = spriteHeight * 0.82;
      const groundY =
        viewHeight / 2 + ((EYE_HEIGHT + playerZ) * viewHeight) / distance;
      const bob = Math.round(Math.sin(worldTime * 5 + mob.direction) * 1.5);
      const top = Math.round(groundY - spriteHeight + bob);
      const left = Math.round(screenX - spriteWidth / 2);
      const right = Math.round(screenX + spriteWidth / 2);

      context.fillStyle = "rgba(18, 35, 29, 0.36)";
      context.fillRect(left + 2, Math.round(groundY) - 2, spriteWidth, 3);
      for (let column = Math.max(0, left); column < Math.min(viewWidth, right); column += 1) {
        if (distance >= depthBuffer[column]) continue;
        context.fillStyle = mob.color;
        context.fillRect(column, top + spriteHeight * 0.24, 1, spriteHeight * 0.76);
        context.fillStyle = "rgba(255, 255, 255, 0.24)";
        context.fillRect(column, top + spriteHeight * 0.3, 1, spriteHeight * 0.12);
      }

      const eyeY = Math.round(top + spriteHeight * 0.43);
      const eyeOffset = Math.max(2, Math.round(spriteWidth * 0.17));
      context.fillStyle = "#172b36";
      if (depthBuffer[Math.max(0, Math.min(viewWidth - 1, screenX - eyeOffset))] > distance) {
        context.fillRect(screenX - eyeOffset, eyeY, 2, 3);
      }
      if (depthBuffer[Math.max(0, Math.min(viewWidth - 1, screenX + eyeOffset))] > distance) {
        context.fillRect(screenX + eyeOffset, eyeY, 2, 3);
      }
    }
  };

  const render = () => {
    const pixels = context.createImageData(viewWidth, viewHeight);
    const data = pixels.data;
    const horizon = Math.floor(viewHeight / 2);
    const eyeHeight = EYE_HEIGHT + playerZ;
    const daylight =
      graphics.dynamicLighting
        ? (Math.sin(worldTime * 0.12) + 1) / 2
        : 1;
    const ambient = graphics.dynamicLighting ? 0.3 + daylight * 0.7 : 1;

    for (let y = 0; y < viewHeight; y += 1) {
      for (let x = 0; x < viewWidth; x += 1) {
        const offset = (y * viewWidth + x) * 4;
        if (y < horizon) {
          const skyShade = (1 - (y / viewHeight) * 0.16) * (0.45 + daylight * 0.55);
          data[offset] = Math.floor(114 * skyShade);
          data[offset + 1] = Math.floor(185 * skyShade);
          data[offset + 2] = Math.floor(232 * skyShade);
          data[offset + 3] = 255;
          continue;
        }

        const screenOffset = y - horizon + 1;
        const rayAngle =
          angle + (x / viewWidth - 0.5) * FIELD_OF_VIEW;
        const correction = Math.max(0.1, Math.cos(rayAngle - angle));
        const perpendicularDistance =
          (eyeHeight * viewHeight) / screenOffset;
        const distance = perpendicularDistance / correction;
        const worldX = playerX + Math.cos(rayAngle) * distance;
        const worldY = playerY + Math.sin(rayAngle) * distance;
        const textureX =
          ((Math.floor((worldX - Math.floor(worldX)) * textureSize) %
            textureSize) +
            textureSize) %
          textureSize;
        const textureY =
          ((Math.floor((worldY - Math.floor(worldY)) * textureSize) %
            textureSize) +
            textureSize) %
          textureSize;
        const textureOffset = (textureY * textureSize + textureX) * 4;
        const shade = Math.max(0.3, 1 - distance * 0.012) * ambient;
        data[offset] = Math.floor(floor.pixels.data[textureOffset] * shade);
        data[offset + 1] = Math.floor(floor.pixels.data[textureOffset + 1] * shade);
        data[offset + 2] = Math.floor(floor.pixels.data[textureOffset + 2] * shade);
        data[offset + 3] = 255;
      }
    }
    context.putImageData(pixels, 0, 0);

    if (graphics.dynamicLighting) {
      const sunX = Math.floor((worldTime * 12) % viewWidth);
      const sunY = Math.floor(13 + (1 - daylight) * 15);
      context.fillStyle = daylight > 0.25 ? "#ffe29a" : "#d9e5ef";
      context.fillRect(sunX, sunY, 8, 8);
    }

    context.fillStyle = "rgba(244, 249, 243, 0.78)";
    context.fillRect(viewWidth * 0.12, viewHeight * 0.135, viewWidth * 0.09, 5);
    context.fillRect(viewWidth * 0.155, viewHeight * 0.115, viewWidth * 0.05, 5);
    context.fillRect(viewWidth * 0.65, viewHeight * 0.215, viewWidth * 0.11, 5);
    context.fillRect(viewWidth * 0.69, viewHeight * 0.195, viewWidth * 0.05, 5);

    const depthBuffer = new Float32Array(viewWidth);
    depthBuffer.fill(Number.POSITIVE_INFINITY);
    for (let column = 0; column < viewWidth; column += 1) {
      const rayAngle =
        angle + (column / viewWidth - 0.5) * FIELD_OF_VIEW;
      const hit = castWall(rayAngle);
      if (!hit) continue;

      const correctedDistance = Math.max(
        0.1,
        hit.distance * Math.cos(rayAngle - angle),
      );
      depthBuffer[column] = correctedDistance;
      const wallHeight = Math.min(
        viewHeight * 5,
        viewHeight / correctedDistance,
      );
      const wallTop =
        viewHeight / 2 -
        ((WALL_HEIGHT - eyeHeight) * viewHeight) / correctedDistance;
      const texture = textures[hit.block].canvas;
      context.drawImage(
        texture,
        hit.textureX,
        0,
        1,
        textureSize,
        column,
        wallTop,
        1.1,
        wallHeight,
      );
      const shadow = Math.min(
        0.82,
        correctedDistance * 0.035 + (graphics.dynamicLighting ? (1 - daylight) * 0.43 : 0),
      );
      if (shadow > 0) {
        context.fillStyle = `rgba(12, 16, 14, ${shadow})`;
        context.fillRect(column, wallTop, 1.1, wallHeight);
      }
    }

    if (graphics.mobCount > 0) renderMobs(depthBuffer);
  };

  const reset = () => {
    map = makeMap(mapSize);
    playerX = mapSize / 2 - 0.5;
    playerY = mapSize / 2 - 0.5;
    playerZ = 0;
    verticalSpeed = 0;
    angle = 0;
    selectedBlock = 1;
    worldTime = 0;
    mobs = createMobs();
    keys.clear();
    render();
    publishState();
  };

  const updateMobs = (deltaTime: number) => {
    for (const mob of mobs) {
      mob.turnIn -= deltaTime;
      if (mob.turnIn <= 0) {
        mob.direction += (Math.random() - 0.5) * 1.8;
        mob.turnIn = 1 + Math.random() * 2.5;
      }

      const step = 0.42 * deltaTime;
      const nextX = mob.x + Math.cos(mob.direction) * step;
      const nextY = mob.y + Math.sin(mob.direction) * step;
      const cellX = Math.floor(nextX);
      const cellY = Math.floor(nextY);
      if (
        cellX > 0 &&
        cellX < mapSize - 1 &&
        cellY > 0 &&
        cellY < mapSize - 1 &&
        map[cellY][cellX] === 0
      ) {
        mob.x = nextX;
        mob.y = nextY;
      } else {
        mob.direction += Math.PI * (0.65 + Math.random() * 0.4);
        mob.turnIn = 0.4;
      }
    }
  };

  const update = (deltaTime: number) => {
    if (graphics.dynamicLighting) {
      worldTime += deltaTime;
      updateMobs(deltaTime);
    }

    if (keys.has("ArrowLeft") || keys.has("KeyA")) angle -= 1.8 * deltaTime;
    if (keys.has("ArrowRight") || keys.has("KeyD")) angle += 1.8 * deltaTime;

    const forward =
      keys.has("ArrowUp") || keys.has("KeyW")
        ? 1
        : keys.has("ArrowDown") || keys.has("KeyS")
          ? -1
          : 0;
    if (forward !== 0) {
      const step = forward * 2 * deltaTime;
      const nextX = playerX + Math.cos(angle) * step;
      const nextY = playerY + Math.sin(angle) * step;
      const canEnter = (x: number, y: number) => {
        const cellX = Math.floor(x);
        const cellY = Math.floor(y);
        if (
          cellX < 1 ||
          cellX >= mapSize - 1 ||
          cellY < 1 ||
          cellY >= mapSize - 1
        ) {
          return false;
        }
        return map[cellY][cellX] === 0 || playerZ >= WALL_HEIGHT;
      };
      if (canEnter(nextX, playerY)) playerX = nextX;
      if (canEnter(playerX, nextY)) playerY = nextY;
    }

    let acceleration = -GRAVITY;
    if (keys.has("KeyR")) acceleration += FLIGHT_THRUST;
    if (keys.has("KeyF")) acceleration -= FLIGHT_THRUST;
    verticalSpeed = Math.max(
      -MAX_VERTICAL_SPEED,
      Math.min(MAX_VERTICAL_SPEED, verticalSpeed + acceleration * deltaTime),
    );

    const cellX = Math.floor(playerX);
    const cellY = Math.floor(playerY);
    const floorHeight = map[cellY]?.[cellX] ? WALL_HEIGHT : 0;
    playerZ += verticalSpeed * deltaTime;
    if (playerZ <= floorHeight) {
      playerZ = floorHeight;
      verticalSpeed = 0;
    } else if (playerZ >= MAX_FLIGHT_HEIGHT) {
      playerZ = MAX_FLIGHT_HEIGHT;
      verticalSpeed = Math.min(0, verticalSpeed);
    }
  };

  const tick = (time: number) => {
    if (!active) return;
    const deltaTime = lastFrame
      ? Math.min(0.05, (time - lastFrame) / 1000)
      : 0;
    lastFrame = time;
    update(deltaTime);
    render();
    if (time - lastReport > 120) {
      publishState();
      lastReport = time;
    }
    frameId = window.requestAnimationFrame(tick);
  };

  const beginLoop = () => {
    if (active) return;
    active = true;
    lastFrame = 0;
    attachListeners();
    frameId = window.requestAnimationFrame(tick);
  };

  onStateChange({
    altitude: 0,
    verticalSpeed: 0,
    grounded: true,
    selectedBlock,
  });
  render();

  return {
    start() {
      reset();
      beginLoop();
    },
    restart() {
      active = false;
      window.cancelAnimationFrame(frameId);
      reset();
      beginLoop();
    },
    pause() {
      active = false;
      window.cancelAnimationFrame(frameId);
      keys.clear();
      publishState();
    },
    resume() {
      beginLoop();
    },
    stop() {
      active = false;
      window.cancelAnimationFrame(frameId);
      removeListeners();
    },
    selectBlock(block) {
      selectedBlock = block;
      publishState();
    },
  };
}
