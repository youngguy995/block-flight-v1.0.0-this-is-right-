import * as THREE from "three";
import type { BlockId, GameEngine, GameSnapshot } from "./engine";

const CHUNK_SIZE = 8;
const ACTIVE_CHUNK_COUNT = 8;
const PLAYER_EYE_HEIGHT = 1.7;
const WALK_SPEED = 5;
const TURN_SPEED = 1.8;
const GRAVITY = 9.8;
const FLIGHT_THRUST = 16;

type BlockKind = "grass" | "stone" | "dirt" | "wood" | "leaves";
type BlockTransform = {
  x: number;
  y: number;
  z: number;
  sx: number;
  sy: number;
  sz: number;
  tint: number;
};
type BlockMesh = THREE.InstancedMesh<
  THREE.BoxGeometry,
  THREE.MeshStandardMaterial
>;
type Chunk = {
  key: string;
  x: number;
  z: number;
  group: THREE.Group;
  meshes: BlockMesh[];
};
type PlacedBlock = {
  x: number;
  y: number;
  z: number;
  kind: BlockId;
};
type Mob = {
  group: THREE.Group;
  direction: number;
  turnIn: number;
};

const BLOCK_KIND_BY_ID: Record<BlockId, BlockKind> = {
  1: "grass",
  2: "stone",
  3: "dirt",
  4: "wood",
};

function hashGrid(x: number, z: number, salt = 0) {
  let value = Math.imul(x + salt, 374761393) + Math.imul(z - salt, 668265263);
  value = Math.imul(value ^ (value >>> 13), 1274126177);
  return ((value ^ (value >>> 16)) >>> 0) / 0x100000000;
}

function createHighDetailMap() {
  const size = 2048;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Could not create Crysis texture canvas.");

  context.fillStyle = "#d9d9d9";
  context.fillRect(0, 0, size, size);

  let seed = 412_791;
  const random = () => {
    seed = (Math.imul(seed, 1_664_525) + 1_013_904_223) >>> 0;
    return seed / 0x1_0000_0000;
  };

  for (let y = 0; y < size; y += 32) {
    for (let x = 0; x < size; x += 32) {
      const shade = Math.floor(150 + random() * 96);
      context.fillStyle = `rgb(${shade}, ${shade}, ${shade})`;
      context.fillRect(x, y, 32, 32);
      if (random() > 0.72) {
        const inset = 3 + Math.floor(random() * 7);
        context.fillStyle = `rgba(255, 255, 255, ${0.08 + random() * 0.16})`;
        context.fillRect(x + inset, y + inset, 5 + random() * 9, 2);
      }
    }
  }

  context.strokeStyle = "rgba(35, 43, 37, 0.14)";
  context.lineWidth = 3;
  for (let line = 0; line <= size; line += 256) {
    context.beginPath();
    context.moveTo(line, 0);
    context.lineTo(line, size);
    context.moveTo(0, line);
    context.lineTo(size, line);
    context.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  return texture;
}

function addInstancedBlocks(
  group: THREE.Group,
  geometry: THREE.BoxGeometry,
  material: THREE.MeshStandardMaterial,
  transforms: BlockTransform[],
): BlockMesh | null {
  if (transforms.length === 0) return null;

  const mesh = new THREE.InstancedMesh(geometry, material, transforms.length);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  const object = new THREE.Object3D();
  transforms.forEach((block, index) => {
    object.position.set(block.x, block.y, block.z);
    object.scale.set(block.sx, block.sy, block.sz);
    object.rotation.set(0, 0, 0);
    object.updateMatrix();
    mesh.setMatrixAt(index, object.matrix);
    mesh.setColorAt(index, new THREE.Color().setScalar(block.tint));
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  group.add(mesh);
  return mesh;
}

export function createCrysisEngine(
  canvas: HTMLCanvasElement,
  onStateChange: (snapshot: GameSnapshot) => void,
): GameEngine {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    depth: true,
    powerPreference: "high-performance",
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));

  const scene = new THREE.Scene();
  scene.background = new THREE.Color("#8fc9d2");
  scene.fog = new THREE.Fog("#8fc9d2", 32, 74);

  const camera = new THREE.PerspectiveCamera(78, 1, 0.08, 110);
  camera.position.set(0, PLAYER_EYE_HEIGHT, 0);
  camera.rotation.order = "YXZ";

  const highDetailMap = createHighDetailMap();
  highDetailMap.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 12);
  const materials: Record<BlockKind, THREE.MeshStandardMaterial> = {
    grass: new THREE.MeshStandardMaterial({
      color: "#a8d984",
      map: highDetailMap,
      roughness: 0.92,
    }),
    stone: new THREE.MeshStandardMaterial({
      color: "#b6c0c4",
      map: highDetailMap,
      roughness: 0.86,
    }),
    dirt: new THREE.MeshStandardMaterial({
      color: "#a6784e",
      map: highDetailMap,
      roughness: 1,
    }),
    wood: new THREE.MeshStandardMaterial({
      color: "#a46638",
      map: highDetailMap,
      roughness: 0.88,
    }),
    leaves: new THREE.MeshStandardMaterial({
      color: "#76b967",
      map: highDetailMap,
      roughness: 0.9,
    }),
  };
  const blockGeometry = new THREE.BoxGeometry(1, 1, 1);
  const mobColors = [0x73e68a, 0xf0ca67, 0xe98e83, 0x94bce8, 0xc29de4, 0xf0a66b];
  const mobGeometry = new THREE.BoxGeometry(0.78, 0.64, 0.72);
  const mobEyeGeometry = new THREE.BoxGeometry(0.09, 0.11, 0.055);
  const mobEyeMaterial = new THREE.MeshStandardMaterial({ color: "#172733", roughness: 0.35 });
  const mobBodyMaterials = mobColors.map(
    (color) =>
      new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.12,
        roughness: 0.58,
      }),
  );

  const hemisphere = new THREE.HemisphereLight("#d5efff", "#3d4936", 1.65);
  scene.add(hemisphere);
  const ambient = new THREE.AmbientLight("#dce8d1", 0.4);
  scene.add(ambient);

  const sun = new THREE.DirectionalLight("#ffe1a0", 3.2);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -32;
  sun.shadow.camera.right = 32;
  sun.shadow.camera.top = 32;
  sun.shadow.camera.bottom = -32;
  sun.shadow.camera.near = 0.5;
  sun.shadow.camera.far = 96;
  sun.shadow.bias = -0.0004;
  scene.add(sun);
  scene.add(sun.target);

  const loadedChunks = new Map<string, Chunk>();
  const placedBlocks = new Map<string, PlacedBlock>();
  const placedByChunk = new Map<string, Set<string>>();
  const placedMeshes = new Map<string, THREE.Mesh>();
  const mobs: Mob[] = [];
  const keys = new Set<string>();
  const raycaster = new THREE.Raycaster();
  const centerOfScreen = new THREE.Vector2(0, 0);

  let playerFeetY = 0;
  let verticalSpeed = 0;
  let yaw = 0;
  let worldTime = 0;
  let selectedBlock: BlockId = 1;
  let active = false;
  let frameId = 0;
  let lastFrame = 0;
  let lastReport = 0;
  let lastChunkKey = "";
  let listenersAttached = false;

  const chunkKey = (x: number, z: number) => `${x},${z}`;
  const placedKey = (x: number, y: number, z: number) => `${x},${y},${z}`;

  const createChunk = (chunkX: number, chunkZ: number): Chunk => {
    const key = chunkKey(chunkX, chunkZ);
    const group = new THREE.Group();
    group.position.set(chunkX * CHUNK_SIZE, 0, chunkZ * CHUNK_SIZE);

    const terrain: BlockTransform[] = [];
    const rocks: BlockTransform[] = [];
    const trunks: BlockTransform[] = [];
    const foliage: BlockTransform[] = [];
    for (let z = 0; z < CHUNK_SIZE; z += 1) {
      for (let x = 0; x < CHUNK_SIZE; x += 1) {
        const worldX = chunkX * CHUNK_SIZE + x;
        const worldZ = chunkZ * CHUNK_SIZE + z;
        const variation = hashGrid(worldX, worldZ);
        terrain.push({
          x: x + 0.5,
          y: -0.5,
          z: z + 0.5,
          sx: 0.985,
          sy: 1,
          sz: 0.985,
          tint: 0.88 + variation * 0.2,
        });

        if (Math.abs(worldX) < 2 && Math.abs(worldZ) < 2) continue;
        const detail = hashGrid(worldX, worldZ, 73);
        if (detail > 0.972) {
          trunks.push({
            x: x + 0.5,
            y: 0.82,
            z: z + 0.5,
            sx: 0.38,
            sy: 1.64,
            sz: 0.38,
            tint: 0.86 + detail * 0.12,
          });
          foliage.push(
            {
              x: x + 0.5,
              y: 1.85,
              z: z + 0.5,
              sx: 1.35,
              sy: 0.8,
              sz: 1.35,
              tint: 0.86 + variation * 0.12,
            },
            {
              x: x + 0.5,
              y: 2.45,
              z: z + 0.5,
              sx: 0.82,
              sy: 0.7,
              sz: 0.82,
              tint: 0.92 + detail * 0.08,
            },
          );
        } else if (detail > 0.935) {
          rocks.push({
            x: x + 0.5,
            y: 0.32,
            z: z + 0.5,
            sx: 0.72,
            sy: 0.64,
            sz: 0.72,
            tint: 0.84 + variation * 0.16,
          });
        }
      }
    }

    const meshes = [
      addInstancedBlocks(group, blockGeometry, materials.grass, terrain),
      addInstancedBlocks(group, blockGeometry, materials.stone, rocks),
      addInstancedBlocks(group, blockGeometry, materials.wood, trunks),
      addInstancedBlocks(group, blockGeometry, materials.leaves, foliage),
    ].filter((mesh): mesh is BlockMesh => mesh !== null);
    scene.add(group);

    const chunk: Chunk = { key, x: chunkX, z: chunkZ, group, meshes };
    const placedKeys = placedByChunk.get(key);
    if (placedKeys) {
      for (const placedId of placedKeys) {
        const block = placedBlocks.get(placedId);
        if (block) addPlacedMesh(chunk, placedId, block);
      }
    }
    return chunk;
  };

  const addPlacedMesh = (chunk: Chunk, key: string, block: PlacedBlock) => {
    if (placedMeshes.has(key)) return;
    const mesh = new THREE.Mesh(blockGeometry, materials[BLOCK_KIND_BY_ID[block.kind]]);
    mesh.position.set(
      block.x + 0.5 - chunk.x * CHUNK_SIZE,
      block.y + 0.5,
      block.z + 0.5 - chunk.z * CHUNK_SIZE,
    );
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.userData.placedBlockKey = key;
    chunk.group.add(mesh);
    placedMeshes.set(key, mesh);
  };

  const syncChunks = () => {
    const playerChunkX = Math.floor(camera.position.x / CHUNK_SIZE);
    const playerChunkZ = Math.floor(camera.position.z / CHUNK_SIZE);
    const centerKey = chunkKey(playerChunkX, playerChunkZ);
    if (centerKey === lastChunkKey) return;
    lastChunkKey = centerKey;

    const candidates: { x: number; z: number; distance: number }[] = [];
    for (let z = -2; z <= 2; z += 1) {
      for (let x = -2; x <= 2; x += 1) {
        candidates.push({ x: playerChunkX + x, z: playerChunkZ + z, distance: x * x + z * z });
      }
    }
    candidates.sort((a, b) => a.distance - b.distance);
    const visibleChunks = candidates.slice(0, ACTIVE_CHUNK_COUNT);
    const visibleKeys = new Set(visibleChunks.map(({ x, z }) => chunkKey(x, z)));

    for (const [key, chunk] of loadedChunks) {
      if (visibleKeys.has(key)) continue;
      scene.remove(chunk.group);
      for (const placedId of placedByChunk.get(key) ?? []) placedMeshes.delete(placedId);
      loadedChunks.delete(key);
    }

    for (const position of visibleChunks) {
      const key = chunkKey(position.x, position.z);
      if (!loadedChunks.has(key)) {
        loadedChunks.set(key, createChunk(position.x, position.z));
      }
    }
  };

  const addPlacedBlock = (block: PlacedBlock) => {
    const key = placedKey(block.x, block.y, block.z);
    if (placedBlocks.has(key)) return;
    const chunkX = Math.floor(block.x / CHUNK_SIZE);
    const chunkZ = Math.floor(block.z / CHUNK_SIZE);
    const ownerKey = chunkKey(chunkX, chunkZ);
    placedBlocks.set(key, block);
    if (!placedByChunk.has(ownerKey)) placedByChunk.set(ownerKey, new Set());
    placedByChunk.get(ownerKey)!.add(key);
    const chunk = loadedChunks.get(ownerKey);
    if (chunk) addPlacedMesh(chunk, key, block);
  };

  const removePlacedBlock = (key: string) => {
    const block = placedBlocks.get(key);
    if (!block) return;
    placedMeshes.get(key)?.parent?.remove(placedMeshes.get(key)!);
    placedMeshes.delete(key);
    placedBlocks.delete(key);
    const ownerKey = chunkKey(
      Math.floor(block.x / CHUNK_SIZE),
      Math.floor(block.z / CHUNK_SIZE),
    );
    placedByChunk.get(ownerKey)?.delete(key);
  };

  const addMob = (index: number, x: number, z: number) => {
    const group = new THREE.Group();
    const color = mobColors[index % mobColors.length];
    const body = new THREE.Mesh(
      mobGeometry,
      mobBodyMaterials[index % mobBodyMaterials.length],
    );
    body.position.y = 0.36;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    for (const eyeX of [-0.17, 0.17]) {
      const eye = new THREE.Mesh(mobEyeGeometry, mobEyeMaterial);
      eye.position.set(eyeX, 0.43, -0.37);
      group.add(eye);
    }

    const light = new THREE.PointLight(color, 1.4, 5.5, 2);
    light.position.y = 1;
    group.add(light);
    group.position.set(x, 0, z);
    scene.add(group);
    mobs.push({
      group,
      direction: hashGrid(index, 17, 29) * Math.PI * 2,
      turnIn: 1.5 + index * 0.21,
    });
  };

  for (let index = 0; index < 6; index += 1) {
    const offsets = [
      [-3, -5],
      [2, -7],
      [5, -2],
      [-6, 2],
      [3, 5],
      [-1, 7],
    ][index];
    addMob(index, offsets[0], offsets[1]);
  }

  const resize = () => {
    const bounds = canvas.getBoundingClientRect();
    const width = Math.max(1, Math.round(bounds.width || window.innerWidth));
    const height = Math.max(1, Math.round(bounds.height || window.innerHeight));
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
  };

  const publishState = () => {
    onStateChange({
      altitude: Number(playerFeetY.toFixed(1)),
      verticalSpeed: Number(verticalSpeed.toFixed(1)),
      grounded: playerFeetY <= 0.001 && Math.abs(verticalSpeed) < 0.05,
      selectedBlock,
    });
  };

  const onKeyDown = (event: KeyboardEvent) => {
    if (!active) return;
    if (
      [
        "KeyW",
        "KeyA",
        "KeyS",
        "KeyD",
        "ArrowUp",
        "ArrowDown",
        "ArrowLeft",
        "ArrowRight",
        "KeyR",
        "KeyF",
      ].includes(event.code)
    ) {
      event.preventDefault();
    }
    keys.add(event.code);
  };

  const onKeyUp = (event: KeyboardEvent) => keys.delete(event.code);
  const onBlur = () => keys.clear();

  const pickBlock = () => {
    raycaster.setFromCamera(centerOfScreen, camera);
    const targets = [
      ...Array.from(loadedChunks.values()).flatMap((chunk) => chunk.meshes),
      ...Array.from(placedMeshes.values()),
    ];
    return raycaster.intersectObjects(targets, false)[0] ?? null;
  };

  const onMouseDown = (event: MouseEvent) => {
    if (!active || (event.button !== 0 && event.button !== 2)) return;
    event.preventDefault();
    const hit = pickBlock();
    if (!hit) return;

    const existingKey = hit.object.userData.placedBlockKey;
    if (event.button === 0) {
      if (typeof existingKey === "string") removePlacedBlock(existingKey);
      return;
    }

    if (!hit.face) return;
    const normal = hit.face.normal.clone().transformDirection(hit.object.matrixWorld);
    const target = hit.point.clone().addScaledVector(normal, 0.51);
    addPlacedBlock({
      x: Math.floor(target.x),
      y: Math.floor(target.y),
      z: Math.floor(target.z),
      kind: selectedBlock,
    });
  };

  const onContextMenu = (event: MouseEvent) => event.preventDefault();

  const attachListeners = () => {
    if (listenersAttached) return;
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    window.addEventListener("resize", resize);
    canvas.addEventListener("mousedown", onMouseDown);
    canvas.addEventListener("contextmenu", onContextMenu);
    listenersAttached = true;
  };

  const removeListeners = () => {
    if (!listenersAttached) return;
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    window.removeEventListener("blur", onBlur);
    window.removeEventListener("resize", resize);
    canvas.removeEventListener("mousedown", onMouseDown);
    canvas.removeEventListener("contextmenu", onContextMenu);
    listenersAttached = false;
    keys.clear();
  };

  const collidesAt = (x: number, z: number) => {
    const feetBlock = Math.floor(playerFeetY);
    const headBlock = Math.floor(playerFeetY + 1.6);
    for (let blockZ = Math.floor(z - 0.28); blockZ <= Math.floor(z + 0.28); blockZ += 1) {
      for (let blockX = Math.floor(x - 0.28); blockX <= Math.floor(x + 0.28); blockX += 1) {
        const nearSpawn = Math.abs(blockX) < 2 && Math.abs(blockZ) < 2;
        const decoration = nearSpawn ? 0 : hashGrid(blockX, blockZ, 73);
        const obstacleHeight = decoration > 0.972 ? 2.9 : decoration > 0.935 ? 0.64 : 0;
        if (obstacleHeight > playerFeetY && playerFeetY + 1.6 > 0) return true;
        for (let blockY = feetBlock; blockY <= headBlock; blockY += 1) {
          if (placedBlocks.has(placedKey(blockX, blockY, blockZ))) return true;
        }
      }
    }
    return false;
  };

  const update = (deltaTime: number) => {
    worldTime += deltaTime;
    if (keys.has("ArrowLeft") || keys.has("KeyA")) yaw += TURN_SPEED * deltaTime;
    if (keys.has("ArrowRight") || keys.has("KeyD")) yaw -= TURN_SPEED * deltaTime;

    const forward =
      keys.has("ArrowUp") || keys.has("KeyW")
        ? 1
        : keys.has("ArrowDown") || keys.has("KeyS")
          ? -1
          : 0;
    if (forward !== 0) {
      const movementX = -Math.sin(yaw) * forward * WALK_SPEED * deltaTime;
      const movementZ = -Math.cos(yaw) * forward * WALK_SPEED * deltaTime;
      const nextX = camera.position.x + movementX;
      const nextZ = camera.position.z + movementZ;
      if (!collidesAt(nextX, camera.position.z)) camera.position.x = nextX;
      if (!collidesAt(camera.position.x, nextZ)) camera.position.z = nextZ;
    }

    let acceleration = -GRAVITY;
    if (keys.has("KeyR")) acceleration += FLIGHT_THRUST;
    if (keys.has("KeyF")) acceleration -= FLIGHT_THRUST;
    verticalSpeed = THREE.MathUtils.clamp(
      verticalSpeed + acceleration * deltaTime,
      -7,
      8,
    );
    playerFeetY = Math.max(0, playerFeetY + verticalSpeed * deltaTime);
    if (playerFeetY === 0 && verticalSpeed < 0) verticalSpeed = 0;
    camera.position.y = PLAYER_EYE_HEIGHT + playerFeetY;
    camera.rotation.set(0, yaw, 0);

    for (const mob of mobs) {
      mob.turnIn -= deltaTime;
      if (mob.turnIn <= 0) {
        mob.direction += (Math.random() - 0.5) * 1.8;
        mob.turnIn = 1.2 + Math.random() * 2;
      }
      mob.group.position.x += Math.cos(mob.direction) * deltaTime * 0.9;
      mob.group.position.z += Math.sin(mob.direction) * deltaTime * 0.9;
      mob.group.position.y = 0.04 + Math.sin(worldTime * 4 + mob.direction) * 0.08;
      mob.group.rotation.y = Math.atan2(
        -(camera.position.x - mob.group.position.x),
        -(camera.position.z - mob.group.position.z),
      );
      const distanceToPlayer = Math.hypot(
        mob.group.position.x - camera.position.x,
        mob.group.position.z - camera.position.z,
      );
      if (distanceToPlayer > 64) {
        mob.group.position.x = camera.position.x + (Math.random() - 0.5) * 18;
        mob.group.position.z = camera.position.z + (Math.random() - 0.5) * 18;
      }
    }

    syncChunks();
    const daylight = (Math.sin(worldTime * 0.075) + 1) / 2;
    const sunAngle = worldTime * 0.075;
    sun.position.set(
      camera.position.x + Math.cos(sunAngle) * 26,
      18 + daylight * 13,
      camera.position.z + Math.sin(sunAngle) * 26,
    );
    sun.target.position.set(camera.position.x, 0, camera.position.z);
    sun.target.updateMatrixWorld();
    sun.intensity = 0.45 + daylight * 3.25;
    hemisphere.intensity = 0.5 + daylight * 1.2;
    ambient.intensity = 0.12 + daylight * 0.38;

    const sky = new THREE.Color().setHSL(0.54, 0.42, 0.19 + daylight * 0.43);
    scene.background = sky;
    if (scene.fog instanceof THREE.Fog) scene.fog.color.copy(sky);
  };

  const render = () => {
    renderer.render(scene, camera);
  };

  const reset = () => {
    camera.position.set(0, PLAYER_EYE_HEIGHT, 0);
    playerFeetY = 0;
    verticalSpeed = 0;
    yaw = 0;
    worldTime = 0;
    keys.clear();
    for (const key of [...placedBlocks.keys()]) removePlacedBlock(key);
    const mobStarts = [
      [-3, -5],
      [2, -7],
      [5, -2],
      [-6, 2],
      [3, 5],
      [-1, 7],
    ];
    mobs.forEach((mob, index) => {
      const [x, z] = mobStarts[index];
      mob.group.position.set(x, 0, z);
      mob.direction = hashGrid(index, 17, 29) * Math.PI * 2;
      mob.turnIn = 1.5 + index * 0.21;
    });
    lastChunkKey = "";
    syncChunks();
    publishState();
    render();
  };

  const tick = (time: number) => {
    if (!active) return;
    const deltaTime = lastFrame ? Math.min(0.05, (time - lastFrame) / 1000) : 0;
    lastFrame = time;
    update(deltaTime);
    render();
    if (time - lastReport > 120) {
      publishState();
      lastReport = time;
    }
    frameId = window.requestAnimationFrame(tick);
  };

  const beginLoop = () => {
    if (active) return;
    active = true;
    lastFrame = 0;
    attachListeners();
    frameId = window.requestAnimationFrame(tick);
  };

  resize();
  syncChunks();
  onStateChange({
    altitude: 0,
    verticalSpeed: 0,
    grounded: true,
    selectedBlock,
  });
  render();

  return {
    start() {
      reset();
      beginLoop();
    },
    restart() {
      active = false;
      window.cancelAnimationFrame(frameId);
      reset();
      beginLoop();
    },
    pause() {
      active = false;
      window.cancelAnimationFrame(frameId);
      keys.clear();
      publishState();
    },
    resume() {
      beginLoop();
    },
    stop() {
      active = false;
      window.cancelAnimationFrame(frameId);
      removeListeners();
      for (const chunk of loadedChunks.values()) scene.remove(chunk.group);
      loadedChunks.clear();
      for (const mob of mobs) scene.remove(mob.group);
      mobs.length = 0;
      mobGeometry.dispose();
      mobEyeGeometry.dispose();
      mobEyeMaterial.dispose();
      mobBodyMaterials.forEach((material) => material.dispose());
      highDetailMap.dispose();
      blockGeometry.dispose();
      Object.values(materials).forEach((material) => material.dispose());
      renderer.dispose();
    },
    selectBlock(block: BlockId) {
      selectedBlock = block;
      publishState();
    },
  };
}
