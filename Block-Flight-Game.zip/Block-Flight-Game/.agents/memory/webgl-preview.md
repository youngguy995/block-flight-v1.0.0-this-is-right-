---
name: WebGL preview limitation
description: Why app-preview screenshots cannot verify the Crysis 3D renderer.
---

The Replit app-preview capture browser in this project failed to create a WebGL context. It can verify the title screen but cannot render the Crysis scene; this is an environment capability, not a source-build failure.

**Why:** the capture browser reported that no WebGL driver/context was available.

**How to apply:** use app-preview screenshots for the regular UI and a WebGL-capable browser to verify the in-game 3D scene.
