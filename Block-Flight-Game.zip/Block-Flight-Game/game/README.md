# Block Flight

A small Pygame ray-casting game.

## Run

Use the **Block Flight Game** workflow in Replit, or run:

```bash
python game/main.py
```

## Controls

- **W / Up** and **S / Down**: move
- **A / Left** and **D / Right**: turn
- **Hold R**: fly upward
- **Hold F**: descend faster
- **Left click**: break the nearest block in view
- **Right click**: place a selected block beside the targeted block
- **1–4**: select a block
- **Esc**: quit

Gravity pulls the player back down when upward thrust stops.
