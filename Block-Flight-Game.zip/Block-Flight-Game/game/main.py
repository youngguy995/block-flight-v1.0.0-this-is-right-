import pygame
import math
import sys
import random

# 1. Initialize Engine & Window Configuration
pygame.init()
WIDTH, HEIGHT = 640, 480
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Block Flight — Created by Aditya Dhasmana")
clock = pygame.time.Clock()

TEX_SIZE = 64 # Higher-detail pixel textures for a 16-bit-era look

# 2. GENERATE 16-BIT-STYLE PIXEL TEXTURES
def fill_pixel_clusters(surface, palette, cluster_size=4):
    """Fill a surface with grouped palette colors instead of random pixel noise."""
    for y in range(0, TEX_SIZE, cluster_size):
        for x in range(0, TEX_SIZE, cluster_size):
            color = random.choice(palette)
            pygame.draw.rect(
                surface, color, (x, y, cluster_size, cluster_size)
            )

def create_procedural_textures():
    textures = {}
    
    grass_palette = [
        (32, 126, 42), (42, 151, 48), (57, 171, 58), (83, 187, 69)
    ]
    dirt_palette = [
        (105, 66, 35), (126, 78, 40), (145, 91, 47), (164, 106, 57)
    ]
    stone_palette = [
        (91, 96, 101), (110, 116, 121), (130, 136, 140),
        (151, 156, 159), (169, 173, 175)
    ]

    # 1: Grass block side with a shaded turf cap and clustered dirt pixels.
    grass_surf = pygame.Surface((TEX_SIZE, TEX_SIZE))
    for y in range(0, TEX_SIZE, 4):
        palette = grass_palette if y < 16 else dirt_palette
        for x in range(0, TEX_SIZE, 4):
            pygame.draw.rect(
                grass_surf, random.choice(palette), (x, y, 4, 4)
            )
    pygame.draw.rect(grass_surf, (37, 112, 38), (0, 14, TEX_SIZE, 4))
    for x in range(5, TEX_SIZE, 11):
        blade_height = random.choice((3, 4, 6))
        pygame.draw.line(
            grass_surf, random.choice(grass_palette),
            (x, 14), (x + random.choice((-1, 0, 1)), 14 - blade_height), 2
        )
    textures[1] = grass_surf

    # 2: Stone block with broad tonal clusters and offset masonry seams.
    stone_surf = pygame.Surface((TEX_SIZE, TEX_SIZE))
    fill_pixel_clusters(stone_surf, stone_palette)
    seam = (72, 77, 82)
    pygame.draw.line(stone_surf, seam, (0, 21), (TEX_SIZE - 1, 21), 2)
    pygame.draw.line(stone_surf, seam, (0, 43), (TEX_SIZE - 1, 43), 2)
    pygame.draw.line(stone_surf, seam, (21, 0), (21, 21), 2)
    pygame.draw.line(stone_surf, seam, (43, 22), (43, 43), 2)
    pygame.draw.line(stone_surf, seam, (16, 44), (16, TEX_SIZE - 1), 2)
    pygame.draw.line(stone_surf, (190, 193, 194), (3, 6), (15, 6), 2)
    pygame.draw.line(stone_surf, (190, 193, 194), (28, 31), (37, 31), 2)
    textures[2] = stone_surf

    # 3: Dirt block with warm, clustered earth tones.
    dirt_surf = pygame.Surface((TEX_SIZE, TEX_SIZE))
    fill_pixel_clusters(
        dirt_surf,
        [(105, 62, 31), (126, 75, 36), (145, 88, 43),
         (160, 101, 51), (177, 117, 61)]
    )
    for x, y in ((9, 13), (38, 29), (21, 51), (53, 45)):
        pygame.draw.rect(dirt_surf, (91, 54, 29), (x, y, 5, 4))
        pygame.draw.rect(dirt_surf, (190, 128, 69), (x + 2, y - 2, 4, 3))
    textures[3] = dirt_surf

    # 4: Wood planks with shaded grain and pixel-art knots.
    wood_surf = pygame.Surface((TEX_SIZE, TEX_SIZE))
    wood_palette = [
        (108, 63, 31), (132, 78, 37), (153, 94, 45), (174, 111, 54)
    ]
    fill_pixel_clusters(wood_surf, wood_palette)
    for y in (0, 16, 32, 48, 63):
        pygame.draw.line(wood_surf, (77, 45, 25), (0, y), (63, y), 2)
    for y in (8, 25, 41, 56):
        pygame.draw.line(
            wood_surf, random.choice(wood_palette), (6, y), (27, y), 2
        )
        pygame.draw.line(
            wood_surf, random.choice(wood_palette), (35, y + 2), (57, y + 2), 2
        )
    for x, y in ((13, 8), (44, 25), (22, 41), (50, 56)):
        pygame.draw.ellipse(wood_surf, (78, 45, 24), (x, y, 8, 5), 1)
        pygame.draw.ellipse(wood_surf, (190, 128, 66), (x + 2, y + 1, 4, 2), 1)
    textures[4] = wood_surf

    return textures

TEXTURES = create_procedural_textures()

def create_grass_floor_texture():
    """Create a clustered, top-down grass tile for the floor plane."""
    grass = pygame.Surface((TEX_SIZE, TEX_SIZE))
    fill_pixel_clusters(
        grass,
        [(30, 116, 37), (38, 139, 43), (49, 158, 48),
         (65, 174, 56), (83, 185, 65)]
    )
    pygame.draw.rect(grass, (35, 99, 37), (0, 0, TEX_SIZE, 2))
    pygame.draw.rect(grass, (35, 99, 37), (0, 0, 2, TEX_SIZE))
    for x, y in ((12, 18), (37, 9), (47, 42), (22, 53)):
        pygame.draw.rect(grass, (100, 192, 72), (x, y, 4, 4))
    return grass

FLOOR_TEXTURE = create_grass_floor_texture()

# 3. Create a 16x16 Room Layout Automatically
MAP_SIZE = 16
MAP = [[0 for _ in range(MAP_SIZE)] for _ in range(MAP_SIZE)]

# Build a border wall around the entire map
for i in range(MAP_SIZE):
    MAP[0][i] = 2
    MAP[MAP_SIZE-1][i] = 2
    MAP[i][0] = 2
    MAP[i][MAP_SIZE-1] = 2

# 4. Camera, Flight & Inventory Settings
player_x, player_y = 7.5, 7.5
player_z = 0.0                 # Player's feet height above the ground, in map units
player_angle = 0.0
WALL_HEIGHT = 1.0
PLAYER_EYE_HEIGHT = 0.5
MAX_FLIGHT_HEIGHT = 2.0
GRAVITY = 4.0                  # Map units per second squared
FLIGHT_THRUST = 8.0
MAX_VERTICAL_SPEED = 3.0
player_vz = 0.0

# Inventory slots setup
inventory = [1, 2, 3, 4]
selected_slot = 0              

def can_move_to(x, y):
    """Allow walking through blocks only when the player is high enough."""
    cell_x, cell_y = int(x), int(y)
    # Keep the enclosing wall solid even while flying.
    if not (1 <= cell_x < MAP_SIZE - 1 and 1 <= cell_y < MAP_SIZE - 1):
        return False
    return MAP[cell_y][cell_x] == 0 or player_z >= WALL_HEIGHT

def find_target_block(max_distance=4.0):
    """Find the first wall in the crosshair ray and the adjacent cell before it."""
    previous_cell = (int(player_x), int(player_y))
    ray_x = math.cos(player_angle)
    ray_y = math.sin(player_angle)
    step = 0.025

    for sample in range(1, int(max_distance / step) + 1):
        distance = sample * step
        target_x = player_x + ray_x * distance
        target_y = player_y + ray_y * distance
        if not (0 <= target_x < MAP_SIZE and 0 <= target_y < MAP_SIZE):
            return None, None

        cell = (int(target_x), int(target_y))
        if cell == previous_cell:
            continue

        cell_x, cell_y = cell
        if MAP[cell_y][cell_x] > 0:
            return cell, previous_cell
        previous_cell = cell

    return None, None

FOV = math.pi / 3
HALF_FOV = FOV / 2
CASTED_RAYS = 160
STEP_ANGLE = FOV / CASTED_RAYS
SCALE = WIDTH / CASTED_RAYS

font = pygame.font.SysFont("monospace", 16, bold=True)
menu_title_font = pygame.font.SysFont("monospace", 42, bold=True)
menu_credit_font = pygame.font.SysFont("monospace", 16, bold=True)
menu_button_font = pygame.font.SysFont("monospace", 24, bold=True)
menu_hint_font = pygame.font.SysFont("monospace", 14)

FLOOR_SAMPLE_STEP = 2
floor_buffer = pygame.Surface(
    (CASTED_RAYS, (HEIGHT // 2) // FLOOR_SAMPLE_STEP)
)

def show_title_screen():
    play_button = pygame.Rect(WIDTH // 2 - 110, 296, 220, 62)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    return
            if (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and play_button.collidepoint(event.pos)
            ):
                return

        mouse_pos = pygame.mouse.get_pos()
        hovered = play_button.collidepoint(mouse_pos)

        # Sky and a simple grass-block landscape.
        screen.fill((119, 190, 235))
        pygame.draw.rect(screen, (143, 207, 244), (0, 0, WIDTH, 280))
        pygame.draw.ellipse(screen, (221, 241, 251), (82, 54, 92, 28))
        pygame.draw.ellipse(screen, (221, 241, 251), (420, 83, 112, 30))
        pygame.draw.rect(screen, (91, 154, 70), (0, 390, WIDTH, 90))
        pygame.draw.rect(screen, (54, 139, 52), (0, 390, WIDTH, 12))
        for tile_x in range(0, WIDTH, TEX_SIZE):
            screen.blit(FLOOR_TEXTURE, (tile_x, 402))
            pygame.draw.rect(screen, (112, 72, 42), (tile_x, 434, TEX_SIZE, 46))

        # Pixel-art grass block logo.
        cx, top = WIDTH // 2, 38
        pygame.draw.polygon(
            screen, (74, 190, 73),
            [(cx, top), (cx + 42, top + 22), (cx, top + 44), (cx - 42, top + 22)],
        )
        pygame.draw.polygon(
            screen, (124, 79, 42),
            [(cx - 42, top + 22), (cx, top + 44), (cx, top + 94), (cx - 42, top + 72)],
        )
        pygame.draw.polygon(
            screen, (91, 57, 32),
            [(cx, top + 44), (cx + 42, top + 22), (cx + 42, top + 72), (cx, top + 94)],
        )
        pygame.draw.polygon(
            screen, (55, 155, 52),
            [(cx - 42, top + 22), (cx, top + 44), (cx + 42, top + 22),
             (cx, top + 1)],
        )

        title = menu_title_font.render("BLOCK FLIGHT", True, (248, 250, 230))
        title_shadow = menu_title_font.render("BLOCK FLIGHT", True, (45, 78, 45))
        title_rect = title.get_rect(center=(WIDTH // 2, 169))
        screen.blit(title_shadow, title_rect.move(3, 4))
        screen.blit(title, title_rect)

        credit = menu_credit_font.render(
            "CREATED BY ADITYA DHASMANA", True, (33, 67, 49)
        )
        screen.blit(credit, credit.get_rect(center=(WIDTH // 2, 224)))

        button_color = (56, 158, 75) if hovered else (43, 128, 63)
        pygame.draw.rect(screen, (31, 70, 43), play_button.move(0, 5), border_radius=10)
        pygame.draw.rect(screen, button_color, play_button, border_radius=10)
        pygame.draw.rect(screen, (183, 230, 137), play_button, 3, border_radius=10)
        play_label = menu_button_font.render("PLAY", True, (255, 255, 242))
        screen.blit(play_label, play_label.get_rect(center=play_button.center))

        hint = menu_hint_font.render("CLICK PLAY TO START", True, (43, 74, 49))
        screen.blit(hint, hint.get_rect(center=(WIDTH // 2, 372)))

        pygame.display.flip()
        clock.tick(60)

show_title_screen()

# 5. Core Engine Loop
while True:
    dt = min(clock.tick(30) / 1000.0, 0.05)
    for event in pygame.event.get():
        if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
            pygame.quit()
            sys.exit()
            
        # Inventory numbers hotkeys 1-4
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1: selected_slot = 0
            if event.key == pygame.K_2: selected_slot = 1
            if event.key == pygame.K_3: selected_slot = 2
            if event.key == pygame.K_4: selected_slot = 3

        # Mouse clicks are separate events from KEYDOWN.
        if event.type == pygame.MOUSEBUTTONDOWN:
            target_cell, placement_cell = find_target_block()
            if target_cell is not None:
                target_x, target_y = target_cell
                # Left Click -> Destroy the nearest block in view.
                if event.button == 1:
                    MAP[target_y][target_x] = 0
                # Right Click -> Place beside it, without replacing blocks.
                elif event.button == 3 and placement_cell is not None:
                    place_x, place_y = placement_cell
                    player_cell = (int(player_x), int(player_y))
                    touches_target = (
                        abs(place_x - target_x) + abs(place_y - target_y) == 1
                    )
                    is_inside_room = (
                        0 < place_x < MAP_SIZE - 1
                        and 0 < place_y < MAP_SIZE - 1
                    )
                    if (
                        touches_target
                        and is_inside_room
                        and (place_x, place_y) != player_cell
                        and MAP[place_y][place_x] == 0
                    ):
                        MAP[place_y][place_x] = inventory[selected_slot]

    # --- INPUT HANDLER CONTROLS ---
    keys = pygame.key.get_pressed()
    
    # Left / Right Rotation Camera turn
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:  
        player_angle -= 0.04
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]: 
        player_angle += 0.04
    
    # Forward Navigation (W or Up Arrow)
    if keys[pygame.K_UP] or keys[pygame.K_w]:
        new_x = player_x + math.cos(player_angle) * 0.06
        new_y = player_y + math.sin(player_angle) * 0.06
        if can_move_to(new_x, player_y):
            player_x = new_x
        if can_move_to(player_x, new_y):
            player_y = new_y
            
    # Backward Navigation (S or Down Arrow)
    if keys[pygame.K_DOWN] or keys[pygame.K_s]:
        new_x = player_x - math.cos(player_angle) * 0.06
        new_y = player_y - math.sin(player_angle) * 0.06
        if can_move_to(new_x, player_y):
            player_x = new_x
        if can_move_to(player_x, new_y):
            player_y = new_y
            
    # R provides upward thrust; gravity acts whenever thrust is not enough to
    # counter it. F adds downward thrust. Land on the ground or block tops.
    vertical_acceleration = -GRAVITY
    if keys[pygame.K_r]:
        vertical_acceleration += FLIGHT_THRUST
    if keys[pygame.K_f]:
        vertical_acceleration -= FLIGHT_THRUST
    player_vz = max(
        -MAX_VERTICAL_SPEED,
        min(MAX_VERTICAL_SPEED, player_vz + vertical_acceleration * dt),
    )

    cell_x, cell_y = int(player_x), int(player_y)
    floor_height = WALL_HEIGHT if MAP[cell_y][cell_x] > 0 else 0.0
    player_z += player_vz * dt
    if player_z <= floor_height:
        player_z = floor_height
        player_vz = 0.0
    elif player_z >= MAX_FLIGHT_HEIGHT:
        player_z = MAX_FLIGHT_HEIGHT
        player_vz = min(0.0, player_vz)

    # --- GRAPHICS RENDERING LAYER ---
    screen.fill((135, 206, 235))

    # Raycasting View Loop
    start_angle = player_angle - HALF_FOV
    ray_directions = []
    for ray in range(CASTED_RAYS):
        cur_angle = start_angle + ray * STEP_ANGLE
        ray_directions.append((
            math.cos(cur_angle),
            math.sin(cur_angle),
            math.cos(cur_angle - player_angle),
        ))

    # Cast the grass floor as a perspective plane below the horizon.
    eye_height = PLAYER_EYE_HEIGHT + player_z
    for floor_row in range(floor_buffer.get_height()):
        screen_y = HEIGHT // 2 + floor_row * FLOOR_SAMPLE_STEP + 1
        row_offset = screen_y - HEIGHT // 2
        perpendicular_distance = eye_height * HEIGHT / row_offset
        for ray, (cos_a, sin_a, correction) in enumerate(ray_directions):
            distance = perpendicular_distance / correction
            world_x = player_x + cos_a * distance
            world_y = player_y + sin_a * distance
            texture_x = int((world_x % 1.0) * TEX_SIZE)
            texture_y = int((world_y % 1.0) * TEX_SIZE)
            red, green, blue, _ = FLOOR_TEXTURE.get_at((texture_x, texture_y))
            shade = max(0.28, 1.0 - distance * 0.012)
            floor_buffer.set_at(
                (ray, floor_row),
                (int(red * shade), int(green * shade), int(blue * shade)),
            )
    scaled_floor = pygame.transform.scale(
        floor_buffer, (WIDTH, HEIGHT // 2)
    )
    screen.blit(scaled_floor, (0, HEIGHT // 2))

    for ray, (cos_a, sin_a, correction) in enumerate(ray_directions):
        for depth in range(1, 200):
            dist = depth * 0.06
            target_x = player_x + cos_a * dist
            target_y = player_y + sin_a * dist
            
            if target_x < 0 or target_x >= MAP_SIZE or target_y < 0 or target_y >= MAP_SIZE:
                break
                
            block_type = MAP[int(target_y)][int(target_x)]
            if block_type > 0:
                dist *= correction
                wall_height = min(HEIGHT * 2, int(HEIGHT / (dist + 0.0001)))
                eye_height = PLAYER_EYE_HEIGHT + player_z
                wall_top = int(
                    (HEIGHT // 2)
                    - (WALL_HEIGHT - eye_height) * HEIGHT / (dist + 0.0001)
                )
                
                hit_x = target_x - int(target_x)
                hit_y = target_y - int(target_y)
                
                if abs(hit_y) < 0.05 or abs(hit_y) > 0.95:
                    texture_x = int(hit_x * TEX_SIZE)
                else:
                    texture_x = int(hit_y * TEX_SIZE)
                texture_x = max(0, min(TEX_SIZE - 1, texture_x))
                
                texture_slice = TEXTURES[block_type].subsurface(texture_x, 0, 1, TEX_SIZE)
                
                shadow = max(0, min(255, int(255 - (dist * 25))))
                shadow_surf = pygame.Surface((1, TEX_SIZE))
                shadow_surf.fill((0,0,0))
                shadow_surf.set_alpha(255 - shadow)
                
                final_slice = texture_slice.copy()
                final_slice.blit(shadow_surf, (0,0))
                
                scaled_slice = pygame.transform.scale(final_slice, (int(SCALE) + 1, wall_height))
                screen.blit(scaled_slice, (ray * SCALE, wall_top))
                break

    # --- INVENTORY OVERLAY DRAWING ---
    pygame.draw.rect(screen, (30, 30, 30), (140, HEIGHT - 65, 360, 55), border_radius=6)
    for i in range(4):
        bx = 160 + (i * 85)
        by = HEIGHT - 55
        border_color = (255, 215, 0) if i == selected_slot else (100, 100, 100)
        border_thickness = 4 if i == selected_slot else 1
        pygame.draw.rect(screen, border_color, (bx, by, 36, 36), border_thickness)
        
        block_id = inventory[i]
        icon_thumb = pygame.transform.scale(TEXTURES[block_id], (28, 28))
        screen.blit(icon_thumb, (bx + 4, by + 4))
        
        lbl = font.render(str(i+1), True, (200, 200, 200))
        screen.blit(lbl, (bx + 2, by - 16))

    # Crosshair
    pygame.draw.circle(screen, (255, 0, 0), (WIDTH // 2, HEIGHT // 2), 2)
    altitude_label = font.render(f"ALT {player_z:.1f}  R/F", True, (20, 20, 20))
    screen.blit(altitude_label, (8, 8))

    pygame.display.flip()

